/*
 * Copyright (c) 2012-2020 MIRACL UK Ltd.
 *
 * This file is part of MIRACL Core
 * (see https://github.com/miracl/core).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "arch.h"
#include "ecp_HIFIVE.h"

namespace HIFIVE {

/* Curve HIFIVE */


#if CHUNK==16

#error Not supported

#endif

#if CHUNK==32

using namespace B336_29;

const int CURVE_Cof_I=8;
const BIG CURVE_Cof= {0x8,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
const int CURVE_B_I= 11111;
const BIG CURVE_B= {0x2B67,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
const BIG CURVE_Order= {0x1E9FA805,0x197CACB9,0x1E4EEA9E,0x17AD70F,0x1FA9850C,0x38A0A,0x0,0x0,0x0,0x0,0x0,0x4000};
const BIG CURVE_Gx= {0xC,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
const BIG CURVE_Gy= {0x5FE8632,0x15F63428,0xD976C4,0x1AACA194,0x35B6DB5,0x8E3F7A,0x52D1B0E,0xF0A7A36,0x1C161D00,0x8170C70,0x1185AD59,0x181B};
const BIG CURVE_HTPC= {0x5531622,0x11FEDF60,0x182A7392,0x16BAC746,0x1A3512D9,0x49580D5,0xE77C13C,0x1AAC2086,0x1E3A6A5,0x2B61FB8,0x783F9C2,0x6C0};
#endif

#if CHUNK==64

using namespace B336_60;

const int CURVE_Cof_I=8;
const BIG CURVE_Cof= {0x8L,0x0L,0x0L,0x0L,0x0L,0x0L};
const int CURVE_B_I= 11111;
const BIG CURVE_B= {0x2B67L,0x0L,0x0L,0x0L,0x0L,0x0L};
const BIG CURVE_Order= {0xB2F95973E9FA805L,0xC0BD6B87F93BAA7L,0x71415FA9850L,0x0L,0x0L,0x200000000L};
const BIG CURVE_Gx= {0xCL,0x0L,0x0L,0x0L,0x0L,0x0L};
const BIG CURVE_Gy= {0x2BEC68505FE8632L,0x5D5650CA0365DB1L,0x3811C7EF435B6DBL,0x7853D1B14B46CL,0x56502E18E1C161DL,0xC0DC616BL};
const BIG CURVE_HTPC= {0xA3FDBEC05531622L,0x9B5D63A360A9CE4L,0xF092B01ABA3512DL,0xA5D56104339DF04L,0x70856C3F701E3A6L,0x3601E0FEL};
#endif

}
