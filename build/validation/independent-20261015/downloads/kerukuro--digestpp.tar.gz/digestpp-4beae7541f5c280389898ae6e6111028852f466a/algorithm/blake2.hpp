/*
This code is written by kerukuro and released into public domain.
*/

#ifndef DIGESTPP_ALGORITHM_BLAKE2_HPP
#define DIGESTPP_ALGORITHM_BLAKE2_HPP

#include "../hasher.hpp"
#include "detail/blake2_provider.hpp"
#include "mixin/blake2_mixin.hpp"

/// digestpp namespace
namespace digestpp
{

/**
 * @defgroup BLAKE2 BLAKE2
 * @brief BLAKE2 Algorithms
 * @{
 */

/**
 * @brief BLAKE2b hash function
 * 
 * Fast cryptographic hash function optimized for 64-bit platforms.
 *
 * BLAKE2b deliberately reduces the number of rounds from 16 (BLAKE-512) to 12 rounds.
 * The round reduction was based on the argument that BLAKE's original 16 rounds
 * were overly conservative relative to known cryptanalysis. However, users should
 * be aware this is a performance-vs-security trade-off, not a pure improvement.
 * For maximum security margin, consider SHA-3 or original BLAKE.
 *
 * Designed by Jean-Philippe Aumasson, Samuel Neves, Zooko Wilcox-O'Hearn, and Christian Winnerlein.
 * 
 * Standardized as RFC 7693 (Informational, November 2015).
 *
 * @hash
 *
 * @outputsize 8 - 512 bits
 *
 * @defaultsize 512 bits
 *
 * @throw std::runtime_error if the requested digest size is not divisible by 8 (full bytes),
 * or is not within the supported range
 * 
 * **Optional parameters:**
 * - `set_salt()` - 16-byte salt for hash randomization
 * - `set_personalization()` - 16-byte string for domain separation
 * - `set_key()` - Up to 64-byte key for MAC mode (keyed hashing)
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2b digest of a string
 * digestpp::blake2b hasher(256);
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 01718cec35cd3d796dd00020e0bfecb473ad23457d063b75eff29c0ffa2e58a9
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2xb, digestpp::blake, digestpp::static_size::blake2b
 */
typedef hasher<detail::blake2_provider<uint64_t, detail::blake2_type::hash>, mixin::blake2_mixin> blake2b;

/**
 * @brief BLAKE2s hash function
 * 
 * Fast cryptographic hash function optimized for 8- to 32-bit platforms.
 * Designed for environments where BLAKE2b's 64-bit operations are not optimal.
 *
 * BLAKE2s reduces the number of rounds from 14 (BLAKE-256) to 10 rounds,
 * The round reduction was based on the argument that BLAKE's original 16 rounds
 * were overly conservative relative to known cryptanalysis. However, users should
 * be aware this is a performance-vs-security trade-off, not a pure improvement.
 * For maximum security margin, consider SHA-3 or original BLAKE.
 *
 * Designed by Jean-Philippe Aumasson, Samuel Neves, Zooko Wilcox-O'Hearn, and Christian Winnerlein.
 * 
 * Standardized as RFC 7693 (Informational, November 2015).
 *
 * @hash
 *
 * @outputsize 8 - 256 bits
 *
 * @defaultsize 256 bits
 *
 * @throw std::runtime_error if the requested digest size is not divisible by 8 (full bytes),
 * or is not within the supported range
 *
 * **Optional parameters:**
 * - `set_salt()` - 8-byte salt for hash randomization
 * - `set_personalization()` - 8-byte string for domain separation
 * - `set_key()` - Up to 32-byte key for MAC mode (keyed hashing)
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2s digest of a string
 * digestpp::blake2s hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 606beeec743ccbeff6cbcdf5d5302aa855c256c29b88c8ed331ea1a6bf3c8812
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2xs, digestpp::blake, digestpp::static_size::blake2s
 */
typedef hasher<detail::blake2_provider<uint32_t, detail::blake2_type::hash>, mixin::blake2_mixin> blake2s;

/**
 * @brief BLAKE2xb hash function
 * 
 * Extended output variant of BLAKE2b supporting arbitrary output lengths.
 * Based on BLAKE2b with additional processing for outputs exceeding 64 bytes.
 * 
 * Use this variant when the required hash size is known in advance.
 * For unknown output size (streaming output), use \ref blake2xb_xof
 * 
 * BLAKE2xb outputs are DIFFERENT from BLAKE2b outputs for the same size.
 * For example: blake2xb(512) ≠ blake2b(512)
 *
 * @hash
 *
 * @outputsize arbitrary
 *
 * @defaultsize 512 bits
 *
 * @throw std::runtime_error if the requested digest size is not divisible by 8 (full bytes)
 *
 * **Optional parameters:**
 * - `set_salt()` - 16-byte salt for hash randomization
 * - `set_personalization()` - 16-byte string for domain separation
 * - `set_key()` - Up to 64-byte key for MAC mode
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2xb digest of a string
 * digestpp::blake2xb hasher(256);
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code ca7a0c9c54b4b93c0bee0aa3a4d63e4f7fb87e3e0a9050522377fde76f0b6c01
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, blake2b, blake2xb_xof, blake, digestpp::static_size::blake2xb
 */
typedef hasher<detail::blake2_provider<uint64_t, detail::blake2_type::x_hash>, mixin::blake2_mixin> blake2xb;

/**
 * @brief BLAKE2xs hash function
 * 
 * Extended output variant of BLAKE2s supporting arbitrary output lengths.
 * 
 * Use this variant when the required hash size is known in advance.
 * For unknown output size (streaming output), use \ref blake2xs_xof
 * 
 * BLAKE2xs outputs are DIFFERENT from BLAKE2s outputs for the same size.
 * For example: blake2xs(256) ≠ blake2s(256)
 *
 * @hash
 *
 * @outputsize arbitrary
 *
 * @defaultsize 256 bits
 *
 * @throw std::runtime_error if the requested digest size is not divisible by 8 (full bytes)
 *
 * **Optional parameters:**
 * - `set_salt()` - 8-byte salt for hash randomization
 * - `set_personalization()` - 8-byte string for domain separation
 * - `set_key()` - Up to 32-byte key for MAC mode
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 512-bit BLAKE2xs digest of a string
 * digestpp::blake2xs hasher(512);
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code e709f8377d21507c166e5dd2279a1f58b290792d65dafcc5647b6e439a974227503c341341572725709b874e95f13a438677aa6f9648467fd341e0f3e5421840
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, blake2s, blake2xs_xof, blake, digestpp::static_size::blake2xs
 */
typedef hasher<detail::blake2_provider<uint32_t, detail::blake2_type::x_hash>, mixin::blake2_mixin> blake2xs;

/**
 * @brief BLAKE2xb in XOF mode
 * 
 * Extendable Output Function (XOF) mode of BLAKE2xb.
 * Use when the required output length is not known in advance or when streaming output is needed.
 * 
 * In XOF mode, you can call squeeze() multiple times to generate arbitrary amounts of output.
 * For fixed-length output known in advance, use \ref blake2xb
 *
 * @xof
 *
 * **Optional parameters:**
 * - `set_salt()` - 16-byte salt for hash randomization
 * - `set_personalization()` - 16-byte string for domain separation
 * - `set_key()` - Up to 64-byte key for MAC mode
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Absorb a string and squeeze 32 bytes of output
 * digestpp::blake2xb_xof hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexsqueeze(32) << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 364e84ca4c103df292306c93ebba6f6633d5e9cc8a95e040498e9a012d5ca534
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, kt128, kt256
 */
typedef hasher<detail::blake2_provider<uint64_t, detail::blake2_type::xof>, mixin::blake2_mixin> blake2xb_xof;

/**
 * @brief BLAKE2xs in XOF mode
 * 
 * Extendable Output Function (XOF) mode of BLAKE2xs.
 * 32-bit optimized version. Use when the required output length is not known in advance.
 * 
 * In XOF mode, you can call squeeze() multiple times to generate arbitrary amounts of output.
 * For fixed-length output known in advance, use \ref blake2xs
 *
 * @xof
 *
 * **Optional parameters:**
 * - `set_salt()` - 8-byte salt for hash randomization
 * - `set_personalization()` - 8-byte string for domain separation
 * - `set_key()` - Up to 32-byte key for MAC mode
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Absorb a string and squeeze 32 bytes of output
 * digestpp::blake2xs_xof hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexsqueeze(32) << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 0650cde4df888a06eada0f0fecb3c17594304b4a03fdd678182f27db1238b1747e33c34ae539fe2179a7594442b5cc9a7a0f398bb15ac3095a397de6a60061d6
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, k12
 */
typedef hasher<detail::blake2_provider<uint32_t, detail::blake2_type::xof>, mixin::blake2_mixin> blake2xs_xof;

/** @} */ // End of BLAKE2 group

namespace static_size
{

/**
 * @defgroup BLAKE2 BLAKE2
 * @{
 */

/**
 * @brief BLAKE2b hash function (static-size version)
 * 
 * Variant of BLAKE2b with output size specified as template parameter.
 *
 * @hash
 *
 * @outputsize 8 - 512 bits
 *
 * **Optional parameters:**
 * - `set_salt()` - 16-byte salt
 * - `set_personalization()` - 16-byte personalization
 * - `set_key()` - Up to 64-byte key
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2b digest of a string
 * digestpp::static_size::blake2b<256> hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 01718cec35cd3d796dd00020e0bfecb473ad23457d063b75eff29c0ffa2e58a9
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2b, blake
 */
template<size_t N>
using blake2b = hasher<detail::blake2_provider<uint64_t, detail::blake2_type::hash, N>, mixin::blake2_mixin>;

/**
 * @brief BLAKE2s hash function (static-size version)
 * 
 * Variant of BLAKE2s with output size specified as template parameter.
 *
 * @hash
 *
 * @outputsize 8 - 256 bits
 *
 * **Optional parameters:**
 * - `set_salt()` - 8-byte salt
 * - `set_personalization()` - 8-byte personalization
 * - `set_key()` - Up to 32-byte key
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2s digest of a string
 * digestpp::static_size::blake2s<256> hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code 606beeec743ccbeff6cbcdf5d5302aa855c256c29b88c8ed331ea1a6bf3c8812
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2s, blake
 */
template<size_t N>
using blake2s = hasher<detail::blake2_provider<uint32_t, detail::blake2_type::hash, N>, mixin::blake2_mixin>;

/**
 * @brief BLAKE2xb hash function (static-size version)
 * 
 * Variant of BLAKE2xb with output size specified as template parameter.
 *
 * @hash
 *
 * @outputsize arbitrary
 *
 * **Optional parameters:**
 * - `set_salt()` - 16-byte salt
 * - `set_personalization()` - 16-byte personalization
 * - `set_key()` - Up to 64-byte key
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 256-bit BLAKE2xb digest of a string
 * digestpp::static_size::blake2xb<256> hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code ca7a0c9c54b4b93c0bee0aa3a4d63e4f7fb87e3e0a9050522377fde76f0b6c01
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2xb, blake
 */
template<size_t N>
using blake2xb = hasher<detail::blake2_provider<uint64_t, detail::blake2_type::x_hash, N>, mixin::blake2_mixin>;

/**
 * @brief BLAKE2xs hash function (static-size version)
 * 
 * Variant of BLAKE2xs with output size specified as template parameter.
 *
 * @hash
 *
 * @outputsize arbitrary
 *
 * **Optional parameters:**
 * - `set_salt()` - 8-byte salt
 * - `set_personalization()` - 8-byte personalization
 * - `set_key()` - Up to 32-byte key
 *
 * @mixinparams salt, personalization, key
 *
 * @mixin{mixin::blake2_mixin}
 *
 * @par Example:
 * @code // Output a 512-bit BLAKE2xs digest of a string
 * digestpp::static_size::blake2xs<512> hasher;
 * hasher.absorb("The quick brown fox jumps over the lazy dog");
 * std::cout << hasher.hexdigest() << '\n';
 * @endcode
 *
 * @par Example output:
 * @code e709f8377d21507c166e5dd2279a1f58b290792d65dafcc5647b6e439a974227503c341341572725709b874e95f13a438677aa6f9648467fd341e0f3e5421840
 * @endcode
 *
 * @sa hasher, mixin::blake2_mixin, digestpp::blake2xs, blake
 */
template<size_t N>
using blake2xs = hasher<detail::blake2_provider<uint32_t, detail::blake2_type::x_hash, N>, mixin::blake2_mixin>;

/** @} */ // End of BLAKE2 group

}

} // namespace digestpp

#endif // DIGESTPP_ALGORITHM_BLAKE2_HPP
