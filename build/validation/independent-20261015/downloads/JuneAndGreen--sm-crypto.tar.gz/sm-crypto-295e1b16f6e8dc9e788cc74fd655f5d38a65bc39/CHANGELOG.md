## 0.5.7

* 修复 sm2 传入以 `00` 前缀开头的公钥（无穷远点 sentinel）时，doVerifySignature/doEncrypt 抛出未捕获 TypeError 导致进程崩溃的问题
* 修复 sm2.doEncrypt 从未对公钥做校验，传入空串或未识别前缀（如 `05`、`ff`）等畸形公钥会抛出未捕获 TypeError 导致进程崩溃的问题；现改为在入口先做公钥合法性校验，非法则抛出可捕获的 `Error('Invalid public key')`
* sm2 的 `decodePointHex` 对各前缀强制校验编码长度，长度非法统一返回 `null`
* 修复 sm2.doSignature/doVerifySignature 传入 `Uint8Array` 与内容等价的普通 `Array` 得到的签名不能互相验证的问题：`arrayToHex` 改用显式循环，对 `Array`/`Uint8Array`/`Buffer` 等所有类数组一致处理；doSignature/doVerifySignature 入参统一归一化

## 0.5.6

* 修复 sm2 在非 node 平台被判断成使用 node crypto 引发的报错

## 0.5.5

* 修复 sm2 der 编码校验不规范问题

## 0.5.4

* 修复 sm2 在调用 doVerifySignature 时传入不可解析公钥会抛出异常的问题

## 0.5.0

* sm2 随机数在 nodejs 环境改用 crypto 生成

## 0.4.0

* sm2 签名/验签函数参数 `hash` 默认为 `true`

## 0.3.14

* 完善 sm2 解密和验签时的逻辑

## 0.3.13

* 支持根据私钥获取公钥

## 0.3.12

* 优化 sm3 运行性能

## 0.3.11

* sm2 支持压缩公钥

## 0.3.10

* 支持 sm3 hmac 模式


## 0.3.9

* 补充 sm4 解密时的 padding 判断

## 0.3.8

* sm2 解密时兼容密文可能是大写的情况

## 0.3.7

* 默认填充改为 pkcs#7，如传入 pkcs#5 也转到 pkcs#7 逻辑

## 0.3.6

* sm2 加解密支持二进制数据

## 0.3.5

* sm2.generateKeyPairHex 支持完整的 BigInteger 入参

## 0.3.4

* sm2 支持验证公钥接口
* sm2 生成密钥时支持自定义随机数

## 0.3.3

* dist 输出改成 umd 模式

## 0.3.2

* 修复 sm2 在 userId 长度大于 31 时新旧版本验签不通过的问题

## 0.3.0

* sm2、sm3 重构
* sm4 支持 cbc 模式

## 0.2.7

* 优化 sm3 性能

## 0.2.5

* sm3 支持字节数组输入

## 0.2.4

* 修复 sm4 四字节字符输出编码

## 0.2.3

* sm3/sm4 支持输入四字节字符

## 0.2.2

* sm3 支持中文输入

## 0.2.1

* 修复 sm2 点 16 进制串可能不满 64 位的问题

## 0.2.0

* sm4 默认支持 pkcs#5 填充方式
* sm4 支持输入输出为字符串
